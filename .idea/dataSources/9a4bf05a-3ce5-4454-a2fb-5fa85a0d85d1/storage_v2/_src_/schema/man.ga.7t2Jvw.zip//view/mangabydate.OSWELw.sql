create view mangabydate as
select `man.ga`.`manga`.`id`          AS `id`,
       `man.ga`.`manga`.`name`        AS `name`,
       `man.ga`.`manga`.`author`      AS `author`,
       `man.ga`.`manga`.`typeID`      AS `typeID`,
       `man.ga`.`manga`.`status`      AS `status`,
       `man.ga`.`manga`.`description` AS `description`,
       `man.ga`.`manga`.`chapters`    AS `chapters`,
       `man.ga`.`manga`.`last_update` AS `last_update`
from `man.ga`.`manga`
order by (case
            when ((right(left(`man.ga`.`manga`.`last_update`, 2), 1) = ' ') and
                  (right(left(`man.ga`.`manga`.`last_update`, 3), 1) = 'd')) then 0
            when ((right(left(`man.ga`.`manga`.`last_update`, 2), 1) = ' ') and
                  (right(left(`man.ga`.`manga`.`last_update`, 3), 1) = 'w')) then 1
            when ((right(left(`man.ga`.`manga`.`last_update`, 2), 1) = ' ') and
                  (right(left(`man.ga`.`manga`.`last_update`, 3), 1) = 'm')) then 2
            when ((right(left(`man.ga`.`manga`.`last_update`, 2), 1) = ' ') and
                  (right(left(`man.ga`.`manga`.`last_update`, 3), 1) = 'y')) then 3
            else 5 end),`man.ga`.`manga`.`last_update`;

