create view average_rating as
select `man.ga`.`rating`.`mangaID`       AS `mangaID`,
       avg(`man.ga`.`rating`.`rating`)   AS `avgRating`,
       count(`man.ga`.`rating`.`rating`) AS `votes`
from `man.ga`.`rating`
group by `man.ga`.`rating`.`mangaID`;

